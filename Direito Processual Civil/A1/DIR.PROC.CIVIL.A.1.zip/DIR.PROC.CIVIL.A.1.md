---
disciplina: DIREITO PROCESSUAL CIVIL
tags:
excalidraw-plugin: parsed
data_criacao: 2026-08-25
professora: MARCELO RIBEIRO
assunto: |-
  1. Estado e ordenamento jurídico
  2. Sistema Processual Cooperativo construído por Normas Fundamentais
  3. Teoria geral do processo
  4. Normas Fundamentais
caminho: DIREITO PROCESSUAL CIVIL Aula 1
---

- [[1. Estado e ordenamento jurídico]]
- [[2. Sistema Processual Cooperativo construído por Normas Fundamentais]]
- [[3. Teoria geral do processo]]
- [[4. Normas Fundamentais]]

![[DIR.PROC.CIVIL.A.1-img1-pg1.png]]

**ANALISTA** DIREITO PROCESSUAL CIVIL MARCELO RIBEIRO AULA 1

- [[ROTEIRO DE AULA]]
- [[Tema Macro: Normas Fundamentais]]
- [[Sumário]]
- [[1. Estado e ordenamento jurídico]]
- [[2. Sistema Processual Cooperativo construído por Normas Fundamentais]]
- [[3. Teoria geral do processo]]
- [[4. Normas Fundamentais 1.cooperação 2.contraditório 3.adequação]]
- [[4. Isonomia]]
- [[5. Primazia do mérito 6.publicidade 7.boa fé]]
- [[8. Acesso ao sistema de justiça]]
- [[9. Fudamentação]]
- [[10. Coerência]]
- [[11. Integridade]]
- [[12. Devido processo legal]]

---
*p. 1*

---

**TEMA: ESTADO E ORDENAMENTO JURÍDICO**

- Estado de direito

  - Lei como instrumento de segurança para o cidadão

  - Na perspectiva econômica: Estado liberal

  - Poder exercido com limites

  - Princípio da legalidade

  - Segurança jurídica e ao jurisdicionado frente ao abuso Estatal

  - Estado atuando no limite e em concomitância com a lei

  - Estado liberal considerando que todos estão em paridade de armas

  - Afirmação da isonomia formal

  - Paridade de armas

- CPC/73

![[DIR.PROC.CIVIL.A.1-img2-pg2.png]]

![[DIR.PROC.CIVIL.A.1-img3-pg2.png]]

![[DIR.PROC.CIVIL.A.1-img4-pg2.png]]

---
*p. 2*

---

  - Racionalidade: procedimento cartesiano (concatenado; racional; burocrático)

  - Legalidade estrita

  - Código técnico

  - Previsibilidade e segurança jurídica

  - ex. pedido implícito: perdas e danos

- Estado democrático de direito

  - Lei como instrumento de segurança (ainda)

  - Isonomia material

  - Estado se propõe à facticidade (diálogo com o caso concreto)

  - Democracia substancial: protege minorias de maiorias (minorias consideradas a partir da qualidade da relação social e não pela quantidade)

  - Procedimentos escritos, mas que investe em novas técnicas para dialogar com o caso concreto

- CPC/15

![[DIR.PROC.CIVIL.A.1-img5-pg3.png]]

![[DIR.PROC.CIVIL.A.1-img6-pg3.png]]

![[DIR.PROC.CIVIL.A.1-img7-pg3.png]]

---
*p. 3*

---

  - Novas técnicas: princípios, conceitos jurídicos indeterminados e cláusulas gerais (visam dialogar com o caso concreto)

  - A par das regras, que são procedimentos pré-determinados: princípios

  - Regras e princípios em conjunto

  - Regras específicas: ex. prazo determinado para pagar quantia certa

  - Flexibilização dos procedimentos (ex. art. 190 – negócio processual; “prazo razoável”; “medida necessária”)

  - ex. aplicação das novas técnicas: condenação em obrigação de fazer de uma troca de janela (prazo razoável conforme o caso concreto – identidade da demanda como referência; multa por descumprimento conforme o caso concreto); processo público, mas com alguns casos em segredo de justiça com base no interesse público (conceito jurídico indeterminado); boa-fé objetiva ; apreensão de CNH: se a pessoa não tem carro, não serve de nada; agora, se for um motorista de aplicativo, a medida se torna extremamente severa.

  - Negociação: desestruturação do procedimento; medidas adequadas ao caso; identidade do caso delimitando aspectos processuais (ex. art. 190 – negócio jurídico)

  - Veja que a isonomia material traz essa pluralidade de possibilidades conforme o caso concreto; se fosse isonomia formal, seria um único mecanismo para todos os casos

**TEMA: SISTEMA PROCESSUAL COOPERATIVO CONSTRUÍDO POR NORMAS FUNDAMENTAIS**

![[DIR.PROC.CIVIL.A.1-img8-pg4.png]]

**2.1. Modelos de sistema processual (convívio entre os sistemas e seus resquícios)**

**a) Inquisitorial**

  - Juiz como protagonista

  - Juiz como destinatário da prova

  - Juiz atua de ofício (sem provocação)

![[DIR.PROC.CIVIL.A.1-img9-pg4.png]]

---
*p. 4*

---

  - Juiz concentra, com exclusividade, poderes para conduzir a relação processual

  - Poderes demasiados ao magistrado

  - CPC 2015 possui alguns resquícios desse sistema inquisitorial:

-Juiz, ainda hoje, possui poderes instrutórios e pode determinar de ofício a produção de uma prova

**b) Adversarial ou acusatório**

  - CPC/73

  - Juiz não detém, com exclusividade, poderes para conduzir a relação processual

  - As partes possuem alguns poderes (ainda que menores que o do juiz)

  - Relação processual triangular ou piramidal (partes na base e o juiz no ápice; partes possuem alguma ingerência, mas ainda muito aquém do magistrado)

  - ex. de poderes das partes: pedido de suspensão do processo, uma única vez, por até 6 meses; cláusula de eleição de foro;

**Bloco 2**

**c) Cooperativo**

  - Proposta mais equilibrada

  - Troca-se o modelo piramidal por um mais equilibrado

  - As partes ganham mais poderes

  - CPC/15

  - Magistrado com mais responsabilidades

  - ex. de empoderamento das partes: art. 190 do CPC [^1] ; negócio jurídico processual onde as partes podem promover ajustes no procedimento para adequá-las as especificidades do caso concreto (alteração de prazos; criação de legitimidade extraordinária contratual; mudança no ônus do pagamento das custas; não ocorrência de duplo grau, salvo nas hipóteses de reexame necessário; todas as hipóteses de negócio jurídico processual)

  - ex. de acréscimo de responsabilidades do magistrado: art. 489, §1º do CPC [^2] que trata das fundamentações das decisões judiciais

---
*p. 5*

---

  - Por isso, hoje, a representação da relação processual não é mais piramidal, mas sim circular

> [!attention] Atenção!
>   - obs. não confunda sistema cooperativo, explicado acima, com princípio da cooperação, que será explicado abaixo Obs. Abaixo seguem algumas explanações para facilitar o entendimento do próximo grande tema da aula

|isonomia formal (CPC/73)|isonomia material (CPC/15)|

|---|---|

|procedimento único|Diversidade de procedimento

|

|estruturação por meio de regras (regras mais especificas e aplicadas com subsunção; raciocínio matemático; lei especial sobre geral; posterior revogando anterior; conflito resolvido por hierarquia)|Utilização de novas técnicas legislativas (a par das regras; princípios; conceito jurídico indeterminado; cláusulas gerais

|

- Diferença de regras e princípios

  - Regras são mais específicas (ex. prazo de 15 dias para apelar)

  - Princípios são mais vagos (baixa densidade semântica; ex. prazo razoável; mensurado no caso concreto)

-ex. juiz condena o réu em obrigação de fazer; o juiz irá arbitrar o prazo para a concretização da obrigação (prazo razoável); veja que, para saber o que é razoável, deve olhar para o caso concreto; se a obrigação for pintar toda uma frente de um prédio, o prazo deve ser de mais de 30 dias, por exemplo; mas se a obrigação for trocar um vidro de uma janela, 1 dia basta;

  - Não há hierarquia entre regras e princípios

  - Hoje, quem atua na delimitação desses princípios, de forma mais constante, é o STJ. Por isso é relevante acompanhar a jurisprudência do STJ quanto ao processo civil

-ex. bem de família; ideia de família; conceitos que se modificam no tempo, sendo abertos e que necessitam de delimitação

I - se limitar à indicação, à reprodução ou à paráfrase de ato normativo, sem explicar sua relação com a causa ou a questão decidida;

II - empregar conceitos jurídicos indeterminados, sem explicar o motivo concreto de sua incidência no caso;

III - invocar motivos que se prestariam a justificar qualquer outra decisão;

IV - não enfrentar todos os argumentos deduzidos no processo capazes de, em tese, infirmar a conclusão adotada pelo julgador;

V - se limitar a invocar precedente ou enunciado de súmula, sem identificar seus fundamentos determinantes nem demonstrar que o caso sob julgamento se ajusta àqueles fundamentos;

VI - deixar de seguir enunciado de súmula, jurisprudência ou precedente invocado pela parte, sem demonstrar a existência de distinção no caso em julgamento ou a superação do entendimento. § 2º No caso de colisão entre normas, o juiz deve justificar o objeto e os critérios gerais da ponderação efetuada, enunciando as razões que autorizam a interferência na norma afastada e as premissas fáticas que fundamentam a conclusão. § 3º A decisão judicial deve ser interpretada a partir da conjugação de todos os seus elementos e em conformidade com o princípio da boa-fé.

---
*p. 6*

---

**TEMA: TEORIA GERAL DO PROCESSO**

![[DIR.PROC.CIVIL.A.1-img10-pg7.png]]

**1. Conceito**

- Ramo que estuda e regulamenta instrumentos gerais do processo, com objeto na ação (direito), jurisdição (função) e processo (relação jurídica)

> [!attention] Atenção!
> - obs. Todo o sistema processual é construído por um sistema de normas fundamentais. Através dessas normas fundamentais que o sistema processual se estrutura (ação, jurisdição e processo: engrenagens que funcionam por meio desse sistema)

- **Conceito** : É uma disciplina jurídica dedicada à elaboração, à organização e à articulação dos conceitos jurídicos fundamentais processuais.

- Conceitos jurídicos fundamentais processuais: todos aqueles indispensáveis à compreensão jurídica do fenômeno processual, onde quer que ele ocorra.

  - Exemplos: ação, processo, jurisdição e competência

  - Majoritariamente: tem-se o entendimento de que a TGP tem como **objeto de estudo** a ação, jurisdição e o processo

  - Ação como direito

  - Jurisdição como função

  - Processo (meio para o exercício da jurisdição) como relação jurídica

  - Esse conjunto (ação, jurisdição e processo) é articulado para funcionar em harmonia. Isso ocorre mediante um sistema processual

  - Sistema processual construído por meio de normas fundamentais

  - Ação é um [direito] exercido contra o Estado para que ele abandone a inércia (característica da jurisdição) e observe uma [função] através de um processo [relação jurídica de direito público animada pelo contraditório].

---
*p. 7*

---

**TEMA:** N **ORMAS FUNDAMENTAIS**

> [!attention] Atenção!
> **obs** . Normas, nesse tópico, como um gênero do qual regras e princípio são espécies; portanto, serão estudados princípios e regras fundamentais

**1. Cooperação**

> [!attention] Atenção!
> - Obs. Sistema cooperativo diferente do princípio da cooperação

  - Sistema cooperativo traz uma relação processual mais equilibrada

  - Tópico, aqui, aborda o princípio da cooperação

  - Coisas distintas conforme já exposto acima

> [!quote] 
> LEI
> - **Art. 6º** Todos os sujeitos do processo devem cooperar entre si para que se obtenha, em tempo razoável, decisão de mérito justa e efetiva.

- Juiz é sujeito do processo: também deve cooperar

- Autor é sujeito do processo: também deve cooperar

- Réu é sujeito do processo: também deve cooperar

- Há desdobramentos da cooperação para cada sujeito acima (ela pode ser exigida de cada sujeito)

- Princípio da cooperação: é espécie de norma e dotado de exigibilidade → pode-se exigir que se coopere

- Cooperação por parte do autor

  - Juiz marcando a audiência, com antecedência mínima de 30 dias (art. 334)

  - 20 dias, antes da audiência, para citação do réu

  - 10 dias, antes da audiência, réu pode protocolar petição de recusa da audiência

  - A audiência somente é dispensada se a recusa for bilateral (autor e réu se manifestando quanto ao desinteresse da audiência)

  - O autor manifesta, o desinteresse, na própria PI

  - Se o réu não se manifestar, considera-se que possui interesse na audiência

  - Sem recusa bilateral a audiência ocorre

  - veja que, mesmo o autor recusando na PI, se o réu não recusar a audiência, o autor deverá comparecer na audiência → possui o dever de cooperar (ausência injustificada caracteriza ato atentatório à dignidade da justiça, passível de multa para um fundo)

> [!quote] 
> LEI
>   - **Art. 334, § 4º** A audiência não será realizada:
>
> I - se **ambas as partes manifestarem**, expressamente, desinteresse na composição consensual;

- Cooperação por parte do réu

  - O réu, em sua defesa, alega ilegitimidade passiva; o autor acha que está citando o proprietário, mas, em verdade, estava citando o possuidor (caseiro); o citado tem relação com o proprietário, por isso tem condição de identificar

---
*p. 8*

---

quem é o verdadeiro réu; ou seja, o réu coopera para que o real legitimado seja identificado, favorecendo a correção do vício

> [!quote] 
> LEI
>   - **Art. 339. Quando alegar sua ilegitimidade, incumbe ao réu indicar o sujeito passivo** da relação jurídica discutida

**sempre que tiver conhecimento**, sob pena de arcar com as despesas processuais e de indenizar o autor pelos prejuízos decorrentes da falta de indicação.

- Cooperação por parte da magistratura:

> [!quote] 
> LEI
>   - **Art. 321.** O juiz, ao verificar que a petição inicial não preenche os requisitos dos (arts. 319 e 320) ou que apresenta defeitos e irregularidades capazes de dificultar o julgamento de mérito, determinará que o autor, no prazo de 15

(quinze) dias, a emende ou a complete, indicando com precisão o que deve ser corrigido ou completado.

**Petição Inicial** Exigências: Art. 319 e Art. 320

**Petição com vício:** um dos requisitos não foi observado

**Juiz:** Art.321 Tem o dever (de correção) de indicar com precisão

- equívoco (exercendo a cooperação)

**Vício sanado**,

- processo segue com naturalidade

> [!attention] Atenção!
>   - obs. no código anterior, o juiz, agindo dessa forma, acabaria por incorrer em suspeição (relação triangular: deveria estar equidistante das partes)

  - Hoje, convoca-se a magistratura para atuar mais intensamente no processo, cooperando com o processo

  - Lembre-se cooperação é dever

  - Essa cooperação favorece a decisão final, de mérito, podendo ser contra ou a favor do autor

> [!attention] Atenção!
>   - Atenção para o prazo de emenda: 15 dias

> [!quote] 
> LEI
>   - art. 932 demonstra cooperação do tribunal Art. 932. Incumbe ao relator: Parágrafo único. Antes de considerar inadmissível o recurso, o relator concederá o prazo de 5 (cinco) dias ao recorrente para que seja sanado vício ou complementada a documentação exigível.

- Cooperação conjunta

> [!quote] 
> LEI
>   - Art. 357. Não ocorrendo nenhuma das hipóteses deste Capítulo, deverá o juiz, em decisão de saneamento e de organização do processo: § 3º Se a causa apresentar complexidade em matéria de fato ou de direito, deverá o juiz designar audiência para que o saneamento seja feito em cooperação com as partes, oportunidade em que o juiz, se for o caso, convidará as partes a integrar ou esclarecer suas alegações

- Cooperação pelo Tribunal

> [!quote] 
> LEI
>   - Art. 932. Incumbe ao relator:

---
*p. 9*

---

Parágrafo único. Antes de considerar inadmissível o recurso, o relator concederá o prazo de 5 (cinco) dias ao recorrente para que seja sanado vício ou complementada a documentação exigível.

> [!quote] 
> LEI
>   - **Art. 1.003. O prazo para interposição de recurso conta-se da data em que os advogados, a sociedade de**

**advogados, a Advocacia Pública, a Defensoria Pública ou o Ministério Público são intimados da decisão.** § 6º O recorrente comprovará a ocorrência de feriado local no ato de interposição do recurso, e, se não o fizer, o tribunal determinará a correção do vício formal, ou poderá desconsiderá-lo caso a informação já conste do processo eletrônico.

**1.1 JURISPRUDÊNCIA**

  - POSSIBILIDADE DE FIXAÇÃO DE MULTA CIVIL CONTRA O INSS, PELA AUSÊNCIA À AUDIÊNCIA DO art. 334, CPC. Resp. 1.769.949 – SP, 1ª turma. J. 02/10/20 “...Assim, não comparecendo o INSS à audiência de conciliação, inevitável a aplicação da multa prevista no art. 334, § 8o. do CPC/2015, que estabelece que o não comparecimento injustificado do autor ou do réu à audiência de conciliação é considerado ato atentatório à dignidade da Justiça e será sancionado com multa de até 2% da vantagem econômica pretendida ou do valor da causa, revertida em favor da União ou do Estado. Qualquer interpretação passadista desse dispositivo será um retrocesso na evolução do Direito pela via jurisdicional e um desserviço à Justiça.”.

**Bloco 3**

**2. Contraditório**

- Norma como resultado hermenêutico (resultado da interpretação)

- Muitas vezes o texto é o mesmo, mas o sentido atribuído ou construído muda com o tempo (ex. família: sentido mudou com o passar dos tempos)

- O sentido de contraditório também mudou (o texto é o mesmo, mas a norma mudou)

- Contraditório no sistema anterior:

  - Ciência bilateral e

  - Possibilidade de manifestação

- Hoje, contraditório – binômio influência e não surpresa:

  - Influência (assegurar o direito real de as partes influenciarem o resultado) – consequência prática: fundamentação das decisões judiciais; para o juiz julgar um pedido, ele deve passar por todos os argumentos apresentados

  - Não surpresa (decisão judicial não deve surpreender): art. 373, §1º do CPC; ex. o juiz pode inverter o ônus da prova (diante da hipossuficiência probatória, por exemplo), mas deve comunicar as partes para manifestação e para que possam se desincumbir do ônus

---
*p. 10*

---

> [!quote] 
> LEI
> - art. 10 do CPC

  - Veja que nem matéria de ordem pública pode ser conhecida sem antes ouvir as partes

  - ex. falta de pressuposto processual: pode decidir pela extinção, mas antes tem que comunicar as partes

> [!quote] 
> LEI
>   - Art. 10. O juiz não pode decidir, em grau algum de jurisdição, com base em fundamento a respeito do qual não se tenha dado às partes oportunidade de se manifestar, ainda que se trate de matéria sobre a qual deva decidir de ofício.

- 489, §1º: influência

> [!quote] 
> LEI
>   - Art. 489, §1º. Não se considera fundamentada qualquer decisão judicial, seja ela interlocutória, sentença ou acórdão, que:
>
> IV - não enfrentar todos os argumentos deduzidos no processo capazes de, em tese, infirmar a conclusão adotada pelo julgador;

- 373, §1º: não surpresa

> [!quote] 
> LEI
>   - Art. 373. O ônus da prova incumbe: § 1º Nos casos previstos em lei ou diante de peculiaridades da causa relacionadas à impossibilidade ou à excessiva dificuldade de cumprir o encargo nos termos do caput ou à maior facilidade de obtenção da prova do fato contrário, poderá o juiz atribuir o ônus da prova de modo diverso, desde que o faça por decisão fundamentada, caso em que deverá dar à parte a oportunidade de se desincumbir do ônus que lhe foi atribuído. PER RELACIONEM: TEMA 1036 - STJ

1. A fundamentação por referência é permitida, desde que o julgador, ao citar outra decisão, documento ou parecer, enfrente de forma sucinta as novas questões relevantes do processo. Não é necessária uma análise pormenorizada de cada alegação ou prova.

2. No caso de agravo interno, é admitida a reprodução dos fundamentos da decisão original para negar provimento ao recurso, mas apenas quando a parte não apresentar um argumento novo e relevante para ser analisado. Integrativa: colocar a sua perspectiva sobre os fundamentos; não “basta o copiar e colar” (pura)

**2.1 contraditório e precedentes**

> [!attention] Atenção!
> - obs. há exceções em que o contraditório é postergado

> [!quote] 
> LEI
> - art. 332 – improcedência liminar da inicial (ex. contradição com precedente vinculante)

  - Pedido totalmente improcedente nem chega no réu

  - Se o autor não fizer nada, nem se fala em contraditório para o réu (apenas dá ciência ao réu – intima o réu)

  - Se o autor apelar, o réu será citado para contrarrazões (ingressa no processo)

---
*p. 11*

---

> [!quote] 
> LEI
> Art. 332. Nas causas que dispensem a fase instrutória, o juiz, independentemente da citação do réu, julgará liminarmente improcedente o pedido que contrariar:
>
> I - enunciado de súmula do Supremo Tribunal Federal ou do Superior Tribunal de Justiça;
>
> II - acórdão proferido pelo Supremo Tribunal Federal ou pelo Superior Tribunal de Justiça em julgamento de recursos repetitivos;
>
> III - entendimento firmado em incidente de resolução de demandas repetitivas ou de assunção de competência;
>
> IV - enunciado de súmula de tribunal de justiça sobre direito local. § 1º O juiz também poderá julgar liminarmente improcedente o pedido se verificar, desde logo, a ocorrência de decadência ou de prescrição. § 2º Não interposta a apelação, o réu será intimado do trânsito em julgado da sentença, nos termos do art. 241 . § 3º Interposta a apelação, o juiz poderá retratar-se em 5 (cinco) dias. § 4º Se houver retratação, o juiz determinará o prosseguimento do processo, com a citação do réu, e, se não houver retratação, determinará a citação do réu para apresentar contrarrazões, no prazo de 15 (quinze) dias.

> [!quote] 
> LEI
> - art. 311

  - decisão entregue antes de comunicar o réu Art. 311. A tutela da evidência será concedida, independentemente da demonstração de perigo de dano ou de risco ao resultado útil do processo, quando:

I - ficar caracterizado o abuso do direito de defesa ou o manifesto propósito protelatório da parte;

II - as alegações de fato puderem ser comprovadas apenas documentalmente e houver tese firmada em julgamento de casos repetitivos ou em súmula vinculante;

III - se tratar de pedido reipersecutório fundado em prova documental adequada do contrato de depósito, caso em que será decretada a ordem de entrega do objeto custodiado, sob cominação de multa;

IV - a petição inicial for instruída com prova documental suficiente dos fatos constitutivos do direito do autor, a que

  - réu não oponha prova capaz de gerar dúvida razoável. Parágrafo único. Nas hipóteses dos incisos II e III, o juiz poderá decidir liminarmente.

**3. Adequação**

- O CPC viabiliza que as partes promovam ajustes para adequar o procedimento às especificidades do caso concreto. Isso, na busca pela isonomia material (adequação dialogando com a isonomia material)

  - ex. audiências remotas e oitiva de testemunhas em instrução, durante a pandemia; sustentação oral nos tribunais superiores: o regimento do STF foi feito em época diferente da época atual da pandemia

  - Veja que são diversos desafios para o Judiciário, necessitando de ajustes do procedimento para a realidade atual

  - A vida se modifica o tempo todo

- Artigos que representam essa capacidade de ajuste do CPC: art. 190 e 139: ilustram o princípio da adequação

---
*p. 12*

---

> [!quote] 
> LEI
> - art. 190: negócio jurídico processual ou convenção processual

-o juiz exerce controle sobre essas mudanças e convenções, como por exemplo, para evitar o abuso de poder econômico

  - o art. 190 pode ser aplicado no curso do processo (ex. estabelecer que as provas somente serão periciais) ou anteriormente ao processo (ex. cláusula de eleição de foro)

> [!quote] 
> LEI
> **-** **Art. 190.** Versando o processo sobre direitos que admitam autocomposição, é lícito às partes plenamente capazes estipular mudanças no procedimento para ajustá-lo às especificidades da causa e convencionar sobre os seus ônus, poderes, faculdades e deveres processuais, antes ou durante o processo. Parágrafo único. De ofício ou a requerimento, o juiz controlará a validade das convenções previstas neste artigo, recusando-lhes aplicação somente nos casos de nulidade ou de inserção abusiva em contrato de adesão ou em que alguma parte se encontre em manifesta situação de vulnerabilidade.

> [!quote] 
> LEI
> - art. 139 traz os poderes e deveres do magistrado

-Veja que o inciso VI permite que o juiz **AMPLIE** os prazos (* cuidado: o art. 190 permite às partes **ALTERAR**   prazo, para mais ou para menos)

> [!quote] 
> LEI
> -Art. 139. O juiz dirigirá o processo conforme as disposições deste Código, incumbindo-lhe:
>
> I - assegurar às partes igualdade de tratamento;
>
> II - velar pela duração razoável do processo;
>
> III - prevenir ou reprimir qualquer ato contrário à dignidade da justiça e indeferir postulações meramente protelatórias;

**IV -** determinar todas as medidas indutivas, coercitivas, mandamentais ou sub-rogatórias necessárias para assegurar o cumprimento de ordem judicial, inclusive nas ações que tenham por objeto prestação pecuniária;

V - promover, a qualquer tempo, a autocomposição, preferencialmente com auxílio de conciliadores e mediadores judiciais;

**VI**  - dilatar os prazos processuais e alterar a ordem de produção dos meios de prova, adequando-os às necessidades do conflito de modo a conferir maior efetividade à tutela do direito;

VII - exercer o poder de polícia, requisitando, quando necessário, força policial, além da segurança interna dos fóruns e tribunais;

VIII - determinar, a qualquer tempo, o comparecimento pessoal das partes, para inquiri-las sobre os fatos da causa, hipótese em que não incidirá a pena de confesso;

IX - determinar o suprimento de pressupostos processuais e o saneamento de outros vícios processuais;

X - quando se deparar com diversas demandas individuais repetitivas, oficiar o Ministério Público, a Defensoria Pública e, na medida do possível, outros legitimados a que se referem o art. 5º da Lei nº 7.347, de 24 de julho de 1985, e o art. 82 da Lei nº 8.078, de 11 de setembro de 1990, para, se for o caso, promover a propositura da ação coletiva respectiva.

---
*p. 13*

---

Parágrafo único. A dilação de prazos prevista no inciso VI somente pode ser determinada antes de encerrado o prazo regular.

> [!attention] Atenção!
>   - obs. art. 191 demonstrando uma ação conjunta das partes com o magistrado – calendário jurídico processual Art. 191. De comum acordo, o juiz e as partes podem fixar calendário para a prática dos atos processuais, quando for o caso. § 1º O calendário vincula as partes e o juiz, e os prazos nele previstos somente serão modificados em casos excepcionais, devidamente justificados. § 2º Dispensa-se a intimação das partes para a prática de ato processual ou a realização de audiência cujas datas tiverem sido designadas no calendário.

**TEMA 1137 - STJ** "Nas execuções civis submetidas exclusivamente ao código de Código de Processo Civil, a adoção judicial de meios executivos atípicas é cabível, desde que, cumulativamente, sejam ponderados os princípios da efetividade e da menor onerosidade do executado, seja realizada de modo prioritariamente subsidiário, a decisão contém a fundamentação adequada às especificidades do caso, sejam observados os princípios do contraditório, da proporcionalidade e da razoabilidade, inclusive quanto à sua vigência temporal." 

**4 Isonomia material**

> [!quote] 
> LEI
> - Art. 7º É assegurada às partes paridade de tratamento em relação ao exercício de direitos e faculdades processuais, aos meios de defesa, aos ônus, aos deveres e à aplicação de sanções processuais, competindo ao juiz zelar pelo efetivo contraditório

> [!attention] Atenção!
> - obs. veja que a letra de lei fala que cabe ao JUIZ zelar pelo contraditório

- repito: A democracia não é apenas formal (governo da maioria. A democracia deve ser, também, substancial, considerando e protegendo as minorias frente às maiorias que são, muitas vezes, eventuais

**4.1 vulnerabilidades processuais**

> [!attention] Atenção!
> - obs. vulnerabilidade é uma condição particular, podendo ser temporária, involuntária, que impede a parte de praticar, com naturalidade, os atos processuais. Pode ser:

  - geográfica (pode haver dilatação de prazo para auxiliar)

  - econômica (pode haver gratuidade para auxiliar)

  - psicológica

  - técnica

  - tecnológica

  - dentre outros exemplos

---
*p. 14*

---

> [!quote] 
> LEI
> - art. 313: hipóteses de suspensão do processo

  - Resolução 313 do CNJ

  - Veja que os incisos acima não estavam presentes na entrada em vigor do CPC, contudo, necessários os ajustes, foram acrescentados (vulnerabilidade do pai e da mãe durante o período em que a criança é recém-nascida, também vulnerável – delicadeza desse período foi reconhecida ao advogado)

> [!quote] 
> LEI
>   - Art. 313. Suspende-se o processo:
>
> IX - pelo parto ou pela concessão de adoção, quando a advogada responsável pelo processo constituir a única patrona da causa;  (Incluído pela Lei nº 13.363, de 2016).
>
> X - quando o advogado responsável pelo processo constituir o único patrono da causa e tornar-se pai.

> [!quote] 
> LEI
> - art. 53: estabelece a competência pelo foro

  - a alínea “d” foi inserida em 2019 pelos termos da Lei Maria da Penha

  - vulnerabilidade da vítima de violência doméstica e familiar

  - foro, abaixo, é utilizado como área territorial (sentido técnico)

> [!quote] 
> LEI
>   - Art. 53. É competente o foro:
>
> I - para a ação de divórcio, separação, anulação de casamento e reconhecimento ou dissolução de união estável: a) de domicílio do guardião de filho incapaz; b) do último domicílio do casal, caso não haja filho incapaz; c) de domicílio do réu, se nenhuma das partes residir no antigo domicílio do casal;

**d) de domicílio da vítima de violência doméstica e familiar, nos termos da lei Maria da Penha. (Incluída pela Lei**

**nº 13.894, de 2019)**

**Resolução Nº 341 de 07/10/2020 – CNJ** Art. 1º Os tribunais deverão disponibilizar salas para a realização de atos processuais, especialmente depoimentos de partes, testemunhas e outros colaboradores da justiça por sistema de videoconferência em todos os fóruns, garantindo a adequação dos meios tecnológicos aptos a dar efetividade ao disposto no art. 7º do Código de Processo Civil.

**Bloco 4**

**5. Primazia do mérito**

> [!quote] 
> LEI
> - art. 4º: Art. 4. As partes têm o direito de obter em prazo razoável a solução integral do mérito, incluída a atividade satisfativa.

> [!quote] 
> LEI
> - art. 485, §7º (aplicação no 1º grau) “Art. 485. O juiz não resolverá o mérito quando:

---
*p. 15*

---

§ 7º Interposta a apelação em qualquer dos casos de que tratam os incisos deste artigo, o juiz terá 5 (cinco) dias para retratar-se.”

- Em todo o código se percebe essa ideia

- Fazer tudo que é possível para que eventuais vícios sanáveis sejam corrigidos; trabalhar para que a sentença terminativa/processual seja uma exceção

- Sempre que possível a decisão será de mérito

- Todos os sujeitos devem buscar isso

- ex. vício em uma PI; se o magistrado não se preocupasse com a cooperação, simplesmente entregaria uma sentença terminativa, extinguindo o processo;

- Veja abaixo: para chegar no mérito, deve, antes, realizar um juízo de admissibilidade (juiz exercendo dois juízos)

![[DIR.PROC.CIVIL.A.1-img11-pg16.png]]  Se o juízo de admissibilidade for positivo, ele avança para o mérito; se esse primeiro juízo for negativo, não se analisam os pedidos  Pedido: positivo ou negativo ou parcial

- Portanto, hoje, diante de um vício na PI, o juiz aplica o art. 321 (cooperação: dever de correção); corrigido o vício,

  - processo volta a tramitar normalmente, entregando uma segunda decisão, agora definitiva

- A primazia também serve para combater a jurisprudência defensiva:

  - Veja que a mesma ideia ocorre na seara recursal

  - Conhecer ou não conhecer: admissibilidade

  - Prover ou não prover: mérito recursal

> [!quote] 
> LEI
>   - Art. 932. Incumbe ao relator: Parágrafo único. Antes de considerar inadmissível o recurso, o relator concederá o prazo de 5 (cinco) dias ao recorrente para que seja sanado vício ou complementada a documentação

**6. Publicidade**

> [!quote] 
> LEI
> - art. 11 CPC

- Regra é a publicidade

  - Atos e julgamento

  - Publicidade assegura maior controle social

> [!quote] 
> LEI
>   - Art. 11. **Todos os julgamentos** dos órgãos do Poder Judiciário **serão públicos**, e fundamentadas todas as decisões, sob pena de nulidade.

---
*p. 16*

---

**Parágrafo único** . Nos casos de **segredo de justiça**, pode ser autorizada a presença somente das **partes**, de seus

**advogados**, de **defensores** públicos ou do **Ministério** Público

- Exceções: segredo de justiça

  - Quando a publicidade for demasiadamente prejudicial para a intimidade, privacidade e dignidade das partes

  - ex. ações de família

  - A técnica legislativa deve permitir alcançar essas situações para afastar a publicidade (não tem como prever um rol taxativo, por isso, fala-se em interesse público – conceito jurídico indeterminado)

  - Avalia o interesse público, no caso concreto, se presente, a consequência é o segredo de justiça

> [!quote] 
> LEI
>   - Art. 189. Os atos processuais são públicos, todavia tramitam em segredo de justiça os processos:
>
> I - em que o exija o interesse público ou social; (avaliação judicial)
>
> II - que versem sobre casamento, separação de corpos, divórcio, separação, união estável, filiação, alimentos e guarda de crianças e adolescentes; (automático)
>
> III - em que constem dados protegidos pelo direito constitucional à intimidade; (avaliação judicial)
>
> IV - que versem sobre arbitragem, inclusive sobre cumprimento de carta arbitral, desde que a confidencialidade estipulada na arbitragem seja comprovada perante o juízo. (automático)

-ex. inciso I com termo vago “interesse público ou social”: necessita avaliação judicial para delimitação desses termos

**7. Boa-Fé**

> [!quote] 
> LEI
> - “art. 5º: Art. 5º Aquele que de qualquer forma participa do processo deve comportar-se de acordo com a boa fé”.

- Todos que atuam no processo devem ser comportar conforme a boa-fé

- Trata-se da boa-fé objetiva

- Busca implementar uma ética processual: um padrão de conduta a ser observado por todos os participantes da relação processual

- A boa-fé busca impedir que expectativas legitimamente criadas sejam indevidamente frustradas. Com isso, busca se inibir a prática de comportamentos contraditórios

- Trata-se de norma princípio: deve atuar com boa-fé sob pena de arcar com as consequências

  - Multa revertida para o adversário

  - Não se confunde com a multa do ato atentatório à dignidade da justiça (revertida ao Estado)

> [!quote] 
> LEI
> - art. 80 traz algumas hipóteses que caracterizam litigância de má-fé (rol exemplificativo) Art. 80. Considera-se litigante de má-fé aquele que:
>
> I - deduzir pretensão ou defesa contra texto expresso de lei ou fato incontroverso;
>
> II - alterar a verdade dos fatos;

---
*p. 17*

---

III - usar do processo para conseguir objetivo ilegal;

IV - opuser resistência injustificada ao andamento do processo;

V - proceder de modo temerário em qualquer incidente ou ato do processo;

VI - provocar incidente manifestamente infundado;

VII - interpuser recurso com intuito manifestamente protelatório.

  - inciso I

  - há discussão sobre aplicar ou não esse inciso para condutas que contrariam pronunciamentos judiciais obrigatórios (o professor entende que não – há outros dispositivos do código que regulam o tema – art. 332 e 311)

  - ex. de advocacia contra um precedente obrigatório: PI contrariando tese fixada em IRDR: juiz não citará o réu, proferindo sentença de improcedência liminar (art. 332); se o autor não apelar, há coisa julgada

  - se, no exemplo acima, a PI advogasse a favor de um precedente obrigatório: pedido começa falando da tutela de evidência; juiz utiliza o art. 311 para dar provimento satisfativo

  - hoje, a tese é a primeira coisa que se observa antes de ajuizar ação (visto tutela de evidência)

  - por essas exposições acima, o professor entende que não se enquadra no art. 80, I

  - Destaque para os incisos IV e V diante de sua amplitude

  - ex. decisão do STJ: autor, na PI, cumprindo os requisitos do art. 319, informou que não tinha interesse na audiência de conciliação; o réu, citado, não se manifestou dentro dos 10 dias; já que o réu não se manifestou, a audiência ocorreu; na audiência, o autor que disse não ter interesse, comparece; não há ato atentatório à dignidade da justiça até o momento; na audiência, o autor acabou por fazer três propostas para o réu; o réu recusou todas sem justificativa e não propôs alternativas; o STJ entendeu que a atuação do réu violo a ética profissional, considerando atuação de má-fé ao violar uma expectativa legitimamente criada (possibilidade de acordo)

> [!quote] 
> LEI
> - art. 81

  - Veja que o juiz tem o dever de cooperar para evitar esse tipo de conduta

  - O legislador estabelece o dever de o magistrado comunicar a parte de que, ao atuar de determinada maneira, atuará de má-fé, sendo passível de multa (advertência e orientação para evitar a prática de conduta que caracteriza má-fé)

> [!attention] Atenção!
>   - Atenção para o valor: superior a 1% e inferior a 10% do valor da causa

> [!attention] Atenção!
>   - obs. o juiz pode comunicar a parte para que não repita a conduta sob pena de multa ou que não pratique (nenhuma vez) sob pena de multa (atuação preventiva)

  - Veja que a cominação da multa pode ser de ofício ou a requerimento

> [!quote] 
> LEI
>   - Art. 81. **De ofício ou a requerimento, o juiz condenará o litigante de má-fé a pagar multa**, que deverá ser superior a um por cento e inferior a dez por cento do valor corrigido da causa, a indenizar a parte contrária pelos prejuízos que esta sofreu e a arcar com os honorários advocatícios e com todas as despesas que efetuou.

---
*p. 18*

---

![[DIR.PROC.CIVIL.A.1-img12-pg19.png]] Gabarito B

**8. Acesso ao sistema de justiça**

> [!quote] 
> LEI
> - art. 5º, XXXV da CF a lei não excluirá da apreciação do Poder Judiciário lesão ou ameaça a direito;

- Monopólio de jurisdição

  - cabe somente ao Estado exercer a jurisdição, através do Estado Juiz

- De outro lado, não se pode afastar lesão ou ameaça de lesão de direito, já que se o Estado é o único que pode exercer a jurisdição, não haveria para quem recorrer. O monopólio da jurisdição está atrelado à inafastabilidade

> [!quote] 
> LEI
> - art. 3º do CPC aborda a inafastabilidade

  - CPC fala em acesso jurisdicional: mais amplo; sistema de justiça (Poder Judiciário é o principal ator, mas não o único); mediador, conciliador, árbitro são outros exemplos

  - Interessante notar que o CPC, diferente da CF, inverte a palavra ameaça e lesão, colocando a “ameaça” antes da “lesão”. Ressalta-se a preocupação /prioridade com as tutelas preventivas, além da ressarcitória

  - O CPC ressalva a arbitragem: pactuação da via da arbitragem para solução do conflito

  - ex. as partes optam pela arbitragem em um contrato; uma das partes desconsidera essa opção e vai diretamente ao judiciário; o juiz, na petição inicial, ainda não sabe da cláusula de arbitragem; o réu, ao comparecer, poderá alegar que há opção pela arbitragem; se o juiz acatar essa alegação, há extinção do processo e manda resolver na arbitragem; veja que não se fala em inafastabilidade, nesse caso, já que a própria lei faz a ressalva da opção pela arbitragem; atente-se que, se o réu não arguir no primeiro momento, pode ocorrer a preclusão

  - sobre a arbitragem há duas corretes:

  - 1C- apenas o poder judiciário exerce o poder jurisdicional

-2C – poder judiciário como poder principal, mas a arbitragem também é exercício de jurisdição, ainda que privada

> [!attention] Atenção!
>   - obs. sentença arbitral é título executivo judicial

> [!attention] Atenção!
>   - obs.2 sentença arbitral submete-se a coisa julgada

---
*p. 19*

---

- A própria CF ressalva algumas hipóteses que a demanda não é imediatamente apresentada ao Judiciário

> [!quote] 
> LEI
>   - art. 142 da CF – trata das forças armadas; §2º traz exceção para inafastabilidade (não caberá)

> [!quote] 
> LEI
>   - art. 217 da CF, §1º - esgotamento das vias administrativas da justiça desportiva para, então, acessar o judiciário; outra flexibilização da inafastabilidade

> [!quote] 
> LEI
>   - **Art. 142, CF** . As Forças Armadas... § 2º Não caberá _habeas corpus_ em relação a punições disciplinares militares.

> [!quote] 
> LEI
>   - **Art. 217, CF.** É dever do Estado fomentar práticas desportivas formais e não-formais, como direito de cada um, observados:

**§ 1º** O Poder Judiciário só admitirá ações relativas à disciplina e às competições desportivas após esgotarem-se as instâncias da justiça desportiva, regulada em lei.

- STF RE 631.240 (ac previdenciárias e medicamentos)

1. A instituição de condições para o regular exercício do direito de ação é compatível com o art. 5º, XXXV, da Constituição. Para se caracterizar a presença de interesse em agir, é preciso haver necessidade de ir a juízo.

2. A concessão de benefícios previdenciários depende de requerimento do interessado, não se caracterizando ameaça ou lesão a direito antes de sua apreciação e indeferimento pelo INSS, ou se excedido o prazo legal para sua análise. É bem de ver, no entanto, que a exigência de prévio requerimento não se confunde com o exaurimento das vias administrativas.

**Bloco 5**

**9. Fundamentação**

> [!quote] 
> LEI
> - art. 93, IX da CF – direito fundamental do jurisdicionado

- Motivação ou fundamentação: sinônimo nas provas

> [!quote] 
> LEI
> - art. 489, §1º do CPC – não diz o que é uma decisão bem fundamentada; aponta o que não é uma decisão bem fundamentada

> [!quote] 
> LEI
> - Art. 489, §1º. Não se considera fundamentada qualquer decisão judicial, seja ela interlocutória, sentença ou acórdão, que:

![[DIR.PROC.CIVIL.A.1-img13-pg20.png]]

---
*p. 20*

---

  - Interlocutória, sentença ou acórdão – todas devem ser fundamentadas

-Juiz: decisão interlocutória ou sentença

-Órgão colegiado: decisão monocrática (proferida pelo relator, presidente ou vice-presidente); acórdão

> [!attention] Atenção!
>   - Cuidado: acórdão não é decisão de tribunal; tribunal também profere decisão monocrática e há decisões das turmas recursais (dos juizados por exemplo; juízes atuando nessas turmas) → portanto, acordão pode ser entregue pela turma recursal ou por tribunal

  - Inciso I: isonomia material e identidade da demanda

> [!attention] Atenção!
>   - obs. inciso V- distinguishing (distinção) e overruling (superação): fatores distintos da tese ou superação da tese – aplicados em precedentes vinculantes

> [!attention] Atenção!
> **obs. a seguir: aborda-se dois vetores de hermenêutica**

**10. Coerência**

- Ligada à isonomia material

- A decisão será coerente se considerar a identidade/peculiaridade da demanda (leitura constitucional do CPC)

- CASOS SEMELHANTES DEVEM TER RESPOSTAS SEMELHANTES

**11. integridade**

- Associada aos princípios

- DEVEMOS RESPEITAR O HISTÓRICO DAS DECISÕES INSTITUCIONAIS E OS MARCOS CIVILIZATÓRIOS DOS DIR. FUNDAMENTAIS

- Dworkin defende a ideia de integridade no livro “taking rights seriously”

- Os princípios representam um padrão ético que deve ser observado ainda que por uma referência moral (é o preço pago para viver em sociedade) – a comunidade estabelece esse padrão no espaço público

- Romance em cadeia: ex. tomando uma série de TV que está na 3ª temporada no episódio 14; o autor te proporciona a liberdade para escrever o episódio 15 dessa série; veja que não há total liberdade, já que o histórico institucional deve ser respeitado (deve respeitar os episódios anteriores já escritos); se não respeitar, rompe-se a integridade

- Gradativamente, no espaço público, os conceitos jurídicos indeterminados foram construídos: o que é família; razoabilidade, etc; uma decisão judicial não pode desconsiderar essa construção

  - ex. união homoafetiva foi incluída na percepção de união estável; um juiz não pode dizer, em uma decisão, que uma ação desse assunto não pode tramitar na vara de família – quebraria a integridade (o padrão de comportamento)

  - Jurisprudência, artigos, livros, etc. consagram esses padrões

---
*p. 21*

---

  - Essa é a ideia de romance em cadeia: deve respeitar o que foi construído sob pena de romper a integridade e segurança jurídica

**12. Vedação ao não julgamento**

> [!quote] 
> LEI
>   - art. 140 do CPC – vedação ao non liquet (não julgamento)

> [!attention] Atenção!
>   - obs. os princípios gerais do direito, mencionados, não são os princípios constitucionais (rematem aos axiomas do direito romana): a maioria adota os seguintes – dar a cada um o que é seu; viver honestamente e não lesar a ninguém

> [!quote] 
> LEI
>   - Art. 140. O juiz não se exime de decidir sob a alegação de lacuna ou obscuridade do ordenamento jurídico. Parágrafo único. O juiz só decidirá por equidade nos casos previstos em lei.

> [!quote] 
> LEI
>   - Art. 4 o Quando a lei for omissa, o juiz decidirá o caso de acordo com a analogia, os costumes e os princípios gerais de direito. (LINDB)

> [!quote] 
> LEI
>   - Art. 5 o Na aplicação da lei, o juiz atenderá aos fins sociais a que ela se dirige e às exigências do bem comum. (LINDB)

**13. Demanda ou impulso oficial**

> [!quote] 
> LEI
> - Art. 141. O juiz decidirá o mérito nos limites propostos pelas partes, sendo-lhe vedado conhecer de questões não suscitadas a cujo respeito a lei exige iniciativa da parte.

> [!quote] 
> LEI
> - Art. 492. É vedado ao juiz proferir decisão de natureza diversa da pedida, bem como condenar a parte em quantidade superior ou em objeto diverso do que lhe foi demandado

- Uma das características da jurisdição é a inércia

- Para o Estado exercer a função jurisdicional, em regra, precisa ser provocado

- O Estado é provocado pelo exercício do direito de ação

- Após a provocação pelo direito de ação, a ideia é que o processo se desenvolva pelo impulso oficial

- Estado atua nos limites da provocação

- ex. o autor vai provocar o Estado para que, este, exercendo jurisdição, condene o réu no pagamento de indenização por dano moral e material; o Estado pode julgar improcedente, procedente, procedente em partes; em todas o Estado se pronunciará sobre o que foi provocado

- ex. se o autor pedir apenas danos materiais, o juiz apenas poderá se manifestar sobre reste, ainda que esteja convicto que houve grave dano moral; não poderá haver condenação do réu em danos morais, já que o autor não provocou o Estado para isso

- Tudo isso conforme o princípio da demanda: juiz não pode conceder algo distinto ou a mais do que foi pedido

- Há situações em que o Estado pode se pronunciar de ofício: quando a lei autoriza ou quando há interesse público

  - ex. prescrição e decadência: uma pretensão que prescreve em ação de cobrança – não há interesse público, mas a lei autoriza o reconhecimento de ofício

---
*p. 22*

---

  - Portanto, atente-se que há matérias que não são de ordem pública, mas que a Lei autoriza o reconhecimento de ofício

> [!quote] 
> LEI
> - art. 322

> [!quote] 
> LEI
>   - Art. 322. O pedido deve ser certo. § 2º A interpretação do pedido considerará o conjunto da postulação e observará o princípio da boa-fé.

  - Pedido certo: expresso; escrito

  - Diante dessa necessidade quanto ao pedido, há a limitação da atuação judicial

  - §2º permite que a interpretação do pedido seja ampla

-Ex. ação para reconhecer a inexistência da paternidade (pedido certo); pelo princípio da demanda é sobre este que o juiz irá se manifestar; mas, valendo-se do §2º, interpretando o conjunto da postulação, o juiz pode avançar para não apenas reconhecer a inexistência da paternidade, mas também determinar a retificação do registro; trata-se de consequência natural da inexistência de paternidade

> [!quote] 
> LEI
> - art. 370

  - Poderes instrutórios do juiz

  - Influência do sistema inquisitorial (protagonismo da magistratura)

> [!quote] 
> LEI
>   - Art. 370. Caberá ao juiz, de ofício ou a requerimento da parte, determinar as provas necessárias ao julgamento do mérito.

**14. Devido processo legal**

- Princípio mais importante da seara processual (estando no âmbito público e privado)

- Funciona como cláusula aberta (conforme a evolução da sociedade, exige-se o aprimoramento e implementação das garantias processuais)

- A expressão se mantem por anos, mas o sentido muda conforme o tempo (texto é o mesmo, mas a norma muda)

- Processo legal devido: expressão de Watanabe

- Devido processo formal: conjunto de garantias estudadas até aqui (importantes para viabilizar a entrega da decisão)

  - Pode haver decisão sem processo

  - Mas se proferida mediante processo, é assegurado o rol de garantias

  - Conjuga o trinômio vida, liberdade e patrimônio

  - Vida, liberdade e patrimônio

- Devido processo material: razoabilidade e proporcionalidade; necessário diálogo entre as garantias processuais e identidade de demanda

  - Conjuga o trinômio facticidade, pluralidade da democracia e respeito aos direitos fundamentais

---
*p. 23*

---

![[DIR.PROC.CIVIL.A.1-img14-pg24.png]]

![[DIR.PROC.CIVIL.A.1-img15-pg24.png]]

**QUESTÕES** O juiz não pode decidir, em grau algum de jurisdição, com base em fundamento a respeito do qual não se tenha dado às partes oportunidade de se manifestar, salvo na hipótese de matéria sobre a qual deva decidir de ofício Gabarito: Errado Os juízes e os tribunais deverão obedecer à ordem cronológica de conclusão para proferir sentença ou acórdão Gabarito: Errado A jurisdição civil será regida pelas normas processuais brasileiras, ressalvadas as disposições específicas previstas em tratados, convenções ou acordos internacionais de que o Brasil seja parte. Gabarito: Certo É admissível a ação meramente declaratória, desde que não tenha ocorrido a violação do direito Gabarito: Errado

[^1]: Art. 190. Versando o processo sobre direitos que admitam autocomposição, é lícito às partes plenamente capazes estipular mudanças no procedimento para ajustá-lo às especificidades da causa e convencionar sobre os seus ônus, poderes, faculdades e deveres processuais, antes ou durante o processo. Parágrafo único. De ofício ou a requerimento, o juiz controlará a validade das convenções previstas neste artigo, recusando-lhes aplicação somente nos casos de nulidade ou de inserção abusiva em contrato de adesão ou em que alguma parte se encontre em manifesta situação de vulnerabilidade.
[^2]: Art. 489. São elementos essenciais da sentença: I - o relatório, que conterá os nomes das partes, a identificação do caso, com a suma do pedido e da contestação, e o registro das principais ocorrências havidas no andamento do processo; II - os fundamentos, em que o juiz analisará as questões de fato e de direito; III - o dispositivo, em que o juiz resolverá as questões principais que as partes lhe submeterem. § 1º Não se considera fundamentada qualquer decisão judicial, seja ela interlocutória, sentença ou acórdão, que:
